import mysql.connector

db = mysql.connector.connect(
    host="devbdd.iutmetz.univ-lorraine.fr",
    user="beurvill4u_appli",
    password="32201970",
    database="beurvill4u_capteurs"
)