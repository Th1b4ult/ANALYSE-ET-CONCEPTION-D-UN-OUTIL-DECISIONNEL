import paho.mqtt.client as mqtt
import mysql.connector
import json
from datetime import datetime, timedelta

SERVEUR = 'localhost'
PORT = 1883
TOPIC_BASE = 'capteurs/#'

db = mysql.connector.connect(
    host="localhost",
    user="mqtt_user",
    password="motdepasse",
    database="capteurs_db"
)
cursor = db.cursor()

def create_alerts_table():
    query = """
    CREATE TABLE IF NOT EXISTS alertes (
        id INT AUTO_INCREMENT PRIMARY KEY,
        capteur VARCHAR(50),
        type_alerte VARCHAR(20),  -- Modérée ou Critique
        valeur FLOAT,
        debut DATETIME,
        fin DATETIME
    )
    """
    cursor.execute(query)
    db.commit()

create_alerts_table()

def create_table_if_not_exists(table_name):
    create_table_query = f"""
    CREATE TABLE IF NOT EXISTS {table_name} (
        id INT AUTO_INCREMENT PRIMARY KEY,
        valeur FLOAT,
        timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
    )
    """
    cursor.execute(create_table_query)
    db.commit()

def clean_old_data(table_name):
    three_months_ago = datetime.now() - timedelta(days=90)
    query = f"DELETE FROM {table_name} WHERE timestamp < %s"
    cursor.execute(query, (three_months_ago,))
    db.commit()

def detect_alerts(capteur, valeur, timestamp):
    seuils = {
        "temperature": (18, 30, 16, 33),  # (modéré_min, modéré_max, critique_min, critique_max)
        "humidity": (40, 70, 30, 80),
        "sound_level": (None, 500, None, 600),
        "air_quality_co2": (None, 800, None, 1100),
        "nano_particles": (None, 120, None, 150)
    }

    if capteur in seuils:
        mod_min, mod_max, crit_min, crit_max = seuils[capteur]

        if (crit_min and valeur < crit_min) or (crit_max and valeur > crit_max):
            insert_alert(capteur, "Critique", valeur, timestamp)
        
        elif (mod_min and valeur < mod_min) or (mod_max and valeur > mod_max):
            insert_alert(capteur, "Modérée", valeur, timestamp)

def insert_alert(capteur, type_alerte, valeur, timestamp):
    query = "INSERT INTO alertes (capteur, type_alerte, valeur, debut) VALUES (%s, %s, %s, %s)"
    cursor.execute(query, (capteur, type_alerte, valeur, timestamp))
    db.commit()
    print(f"Alerte {type_alerte} détectée pour {capteur} : {valeur} à {timestamp}")

client = mqtt.Client()

def on_connect(client, userdata, flags, rc):
    if rc == 0:
        print("Connecté au broker MQTT")
        client.subscribe(TOPIC_BASE)
    else:
        print(f"Échec de la connexion, code d'erreur : {rc}")

def on_message(client, userdata, msg):
    print(f"Message reçu sur {msg.topic} : {msg.payload.decode()}")
    try:
        data = json.loads(msg.payload.decode())
        valeur = data.get("valeur", None)
        timestamp_reception = datetime.now()

        if valeur is not None:
            capteur = msg.topic.split("/")[-1]
            table_name = f"{capteur}_data"

            create_table_if_not_exists(table_name)
            clean_old_data(table_name)

            query = f"INSERT INTO {table_name} (valeur, timestamp) VALUES (%s, %s)"
            cursor.execute(query, (valeur, timestamp_reception))
            db.commit()
            print(f"Donnée stockée dans '{table_name}' : {valeur} à {timestamp_reception}")

            detect_alerts(capteur, valeur, timestamp_reception)
        else:
            print("Aucune valeur trouvée dans le message.")

    except Exception as e:
        print(f"Erreur lors du stockage des données : {e}")

client.on_connect = on_connect
client.on_message = on_message

print("Démarrage du Subscriber MQTT...")
client.connect(SERVEUR, PORT, 60)
client.loop_forever()
