import paho.mqtt.client as mqtt
import time
import json
import gateway

SERVEUR = 'localhost'
PORT = 1883
TOPIC = 'test_channel'
ACK_TOPIC = 'test_channel/ack'

client = mqtt.Client()
ack_received = False

def on_message_ack(client, userdata, msg):
	global ack_received
	print(f"Accusé de réception reçu : {msg.payload.decode()}")
	ack_received = True

def on_connect(client, userdata, flags, rc):
    if rc == 0:
        print("Connecté au broker MQTT")
        client.subscribe(ACK_TOPIC)
    else:
        print(f"Echec de la connexion, code d'erreur : {rc}")

client.on_connect = on_connect
client.on_message = on_message_ack


client.connect(SERVEUR, PORT, 60)
client.loop_start()

print("Initialisation du Raspberry Pi et des capteurs")
passerelleObject = gateway.gateway()
print("Passerelle prête, démarrage de la collecte des données")

try:
    while True:
        passerelleObject.inputUpdate()
        sensor_data = {
            "temperature": passerelleObject.temperature,
            "humidity": passerelleObject.humidity,
            "sound_level": passerelleObject.sound_level,
            "air_quality_co2": passerelleObject.air_co2,
            "nano_particles": passerelleObject.nano_particles,
            "presence_detected": passerelleObject.presence_detected
        }
        message = json.dumps(sensor_data)
        ack_received = False

        result = client.publish(TOPIC, message, qos=1)

        if result.rc != mqtt.MQTT_ERR_SUCCESS:
            print(f"Échec de l'envoi du message, code d'erreur : {result.rc}")

        print(f"Données publiées sur {TOPIC} : {message}")
        time.sleep(10)
        if not ack_received:
                print("Aucun subscriber n'a confirmé la réception du message")
        time.sleep(1.0)

except KeyboardInterrupt:
    print("\nArrêt du script")

finally:
    client.loop_stop()
    client.disconnect()
    print("Déconnecté du broker MQTT")