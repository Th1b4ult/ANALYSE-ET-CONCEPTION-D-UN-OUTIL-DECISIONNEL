import subprocess

def scan_bluetooth():
	print("Scan des périphériques bluetooth passif")
	try:
		result = subprocess.run(["hcitool", "inq"], capture_output = True, text=True)
		devices = []

		for line in result.stdout.split("\n"):
			parts = line.split("\t")
			if len(parts) > 1:
				adress = parts[1].strip(à
				devices.append({"adress": adress, "name": name=

	except Exception as e:
		print("Erreur lors du scan du Bluetooth")