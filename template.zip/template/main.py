import time
import gateway
from lib.buzzer import buzzer
from lib.ledstick import ledStick

print("Initialisation de l'application")
passerelleObject = gateway.gateway()
print("Lancement de l'application")

buzzer = buzzer.GroveBuzzer(22)
LEDStick = ledStick.GroveLedStick(12,10)

try:
	while True:
		print("----------")
		passerelleObject.inputUpdate()
		passerelleObject.inputProcessing()
		passerelleObject.graph()
		passerelleObject.outputProcessing()
		passerelleObject.outputUpdate()

		time.sleep(1.0)

# Permet d'éteindre le buzzer et la ledstick quand il y a un arrêt manuel (KeyboardInterrupt)
except KeyboardInterrupt:
	buzzer.off()
	LEDStick.LedRGB_AllOFF()