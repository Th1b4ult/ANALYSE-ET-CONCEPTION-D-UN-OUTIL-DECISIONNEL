import time
from lib.buttonLED import buttonLED
from lib.buzzer import buzzer
from lib.ledstick import ledStick
from lib.sensorAirquality import sensorAirquality
from lib.sensorDHT import sensorDHT
from lib.sensorPIR import sensorPIR
from lib.sensorSound import sensorSound
import csv
import os

class gateway:
    def __init__(self):
        # Initialisation de la passerelle et des périphériques
        print("Initialisation de la passerelle")

        # Boutons avec LED intégrées
        self.bLed1 = buttonLED.GroveButtonLed(6, 5)  # Bouton/LED 1
        self.bLed2 = buttonLED.GroveButtonLed(17, 1)  # Bouton/LED 2
        
        # Actionneurs
        self.buzzer = buzzer.GroveBuzzer(22)  # Buzzer (GPIO 22)
        self.led_stick = ledStick.GroveLedStick(12, 10)  # Barre de LED (GPIO 12 pour contrôle)

        # Capteurs
        self.air_quality_sensor = sensorAirquality.GroveAirQualitySensor()  # Capteur de qualité de l'air
        self.dht_sensor = sensorDHT.GroveDHTSensor(26)  # Capteur de température/humidité (GPIO 26)
        self.pir_sensor = sensorPIR.GrovePirMotionSensor(18)  # Capteur de mouvement (GPIO 18)
        self.sound_sensor = sensorSound.GroveSoundSensor(0)  # Capteur sonore (ADC canal 0)

        # Variables d'état
        self.buzzer_status = 0  # État du buzzer (0 : désactivé, 1 : activé)
        self.manual_buzzer_control = False  # Contrôle manuel du buzzer
        self.critical_alert = False  # Indicateur d'alerte critique
        self.presence_detected = False  # Présence détectée par le capteur PIR
        self.previous_presence_state = False  # État précédent de la présence

        # Seuils pour les capteurs
        self.sound_threshold = 500  # Niveau sonore modéré
        self.sound_critical = 600  # Niveau sonore critique
        self.temperature_threshold = (18, 30)  # Température normale (°C)
        self.temperature_critical = (16, 33)  # Température critique (°C)
        self.humidity_threshold = (40, 70)  # Humidité normale (%)
        self.humidity_critical = (30, 80)  # Humidité critique (%)
        self.nano_particles_threshold = 120  # Seuil de nanoparticules modéré
        self.nano_particles_critical = 150  # Seuil de nanoparticules critique
        self.gas_threshold = 800  # Seuil de qualité de l'air modéré (CO2)
        self.gas_critical = 1100  # Seuil de qualité de l'air critique (CO2)

        self.csv_file = "/home/pi/Documents/api/data/sensor_data.csv"
        self.initialize_directory = ("/home/pi/Documents/api/data")
        self.initialize_csv()

    # Nouvelle méthode : Créer le répertoire si nécessaire.
    def initialize_directory(self,directory):
        if not os.path.exists(directory):
           os.makedirs(directory)
           print(f"Répertoire créé : {directory}")

    # Nouvelle méthode : Initialisation du fichier CSV
    def initialize_csv(self):
        if not os.path.exists(self.csv_file):
            with open(self.csv_file, mode='w', newline='') as file:
                writer = csv.writer(file)
                writer.writerow([
                "Timestamp", "Sound_Level", "Temperature", "Humidity",
                "Air_Quality_CO2", "Nano_Particles", "Presence_Detected", "Status_Buzzer",
                "led_sound", "led_temperature", "led_humidity", "led_presence", "led_air_quality", "led_nano_particles"
                ])
        print(f"Fichier CSV initialisé : {self.csv_file}")

    # Nouvelle méthode : Enregistrement des données dans le fichier CSV
    def log_to_csv(self):
        with open(self.csv_file, mode='a', newline='') as file:
            writer = csv.writer(file)
            writer.writerow([
            time.strftime("%Y-%m-%d %H:%M:%S"),  # Horodatage
            self.sound_level,  # Niveau sonore
            self.temperature,  # Température
            self.humidity,  # Humidité
            self.air_co2,  # Qualité de l'air (CO2)
            self.nano_particles,  # Nanoparticules
            self.presence_detected,  # Détection de présence
            self.buzzer_status,  # État du buzzer
            self.led_colors[0],  # led_sound
            self.led_colors[1],  # led_temperature
            self.led_colors[2],  # led_humidity
            self.led_colors[3],  # led_presence
            self.led_colors[4],  # led_air_quality
            self.led_colors[5]   # led_nano_particles
            ])
        print("Données enregistrées dans le fichier CSV")

    def inputUpdate(self):
        # Mise à jour des entrées capteurs et boutons
        print("Mise à jour des entrées")
        # Lecture des boutons
        self.bLed1_status = self.bLed1.getStatusButton()
        self.bLed2_status = self.bLed2.getStatusButton()

        # Réinitialisation des alertes si bouton 1 pressé
        if self.bLed1_status == 0:
            print("Bouton 1 pressé : Réinitialisation des alertes")
            self.critical_alert = False  # Réinitialisation de l'alerte critique
            self.bLed1.setStatusLed(1)  # Allume la LED pour signaler l'action
        else:
            self.bLed1.setStatusLed(0)  # Éteint la LED

        # Contrôle manuel du buzzer si bouton 2 pressé
        if self.bLed2_status == 0:
            print("Bouton 2 pressé : Activation/Désactivation manuelle du buzzer")
            self.manual_buzzer_control = not self.manual_buzzer_control  # Inverse l'état
            self.bLed2.setStatusLed(1 if self.manual_buzzer_control else 0)  # Met à jour la LED

        # Lecture des capteurs
        self.air_quality = self.air_quality_sensor.getRawSensorValue()  # Qualité de l'air brute
        self.nano_particles = self.air_quality_sensor.TVoC()  # Niveau de nanoparticules
        self.air_co2 = self.air_quality_sensor.CO2eq()  # Niveau de CO2
        self.dht = self.dht_sensor.getRawSensorValue()  # Données brutes DHT
        self.temperature = self.dht_sensor.temperature()  # Température
        self.humidity = self.dht_sensor.humidity()  # Humidité
        self.previous_presence_state = self.presence_detected  # Sauvegarde de l'état précédent
        self.presence_detected = self.pir_sensor.getSensorValue()  # Détection de présence
        self.sound_level = self.sound_sensor.getRawSensorValue()  # Niveau sonore

        # Affichage des valeurs lues
        print(f"Niveau sonore : {self.sound_level} (0-1023)")
        print(f"Température : {self.temperature}°C, Humidité : {self.humidity}%")
        print(f"Qualité de l'air (CO2) : {self.air_co2} ppb")
        print(f"Nanoparticules : {self.nano_particles} ppm")
        print(f"Présence détectée : {self.presence_detected}")

        self.graph()
        # Appel de la méthode pour enregistrer les données dans le CSV
        self.log_to_csv()

    def inputProcessing(self):
        # Traitement des données d'entrée pour détecter des alertes
        print("Traitement des entrées")

        self.critical_alert = False  # Réinitialisation de l'alerte critique

        # Vérification des seuils critiques
        if self.sound_level > self.sound_critical:
            print("Alerte critique : Niveau sonore au-dessus du seuil critique")
            self.critical_alert = True

        if not (self.temperature_critical[0] <= self.temperature <= self.temperature_critical[1]):
            print("Alerte critique : Température en dehors des limites critiques")
            self.critical_alert = True

        if not (self.humidity_critical[0] <= self.humidity <= self.humidity_critical[1]):
            print("Alerte critique : Humidité en dehors des limites critiques")
            self.critical_alert = True

        if self.air_co2 > self.gas_critical:
            print("Alerte critique : Qualité de l'air au-dessus du seuil critique (CO2)")
            self.critical_alert = True

        if self.nano_particles > self.nano_particles_critical:
            print("Alerte critique : Nanoparticules au-dessus du seuil critique")
            self.critical_alert = True

        # Réactivation automatique du buzzer si présence détectée auparavant et non maintenant
        if not self.presence_detected and self.previous_presence_state and self.critical_alert:
            print("Aucune présence détectée, réactivation automatique du buzzer")
            self.manual_buzzer_control = False

    def graph(self):
        # Mise à jour des LED pour représenter les états
        print("Mise à jour des LEDs")

        # Liste des couleurs des LED
        self.led_colors = []

        # LED 1 : Niveau sonore
        # Si le niveau sonore dépasse le niveau critique alors la led de la ledstick du associée au composant passe en rouge.
        if self.sound_level > self.sound_critical:
            # Ajoute dans la liste la couleur de la led associée au composant
            self.led_colors.append("Rouge")
            self.led_stick.LedRGB_ON(0, 255, 0, 0)  # Rouge
        elif self.sound_level > self.sound_threshold:
            self.led_colors.append("Orange")
            self.led_stick.LedRGB_ON(0, 255, 165, 0)  # Orange
        else:
            self.led_colors.append("Vert")
            self.led_stick.LedRGB_ON(0, 0, 255, 0)  # Vert

        # LED 2 : Température
        if not (self.temperature_critical[0] <= self.temperature <= self.temperature_critical[1]):
            self.led_colors.append("Rouge")
            self.led_stick.LedRGB_ON(1, 255, 0, 0)  # Rouge
        elif not (self.temperature_threshold[0] <= self.temperature <= self.temperature_threshold[1]):
            self.led_colors.append("Orange")
            self.led_stick.LedRGB_ON(1, 255, 165, 0)  # Orange
        else:
            self.led_colors.append("Vert")
            self.led_stick.LedRGB_ON(1, 0, 255, 0)  # Vert

        # LED 3 : Humidité
        if not (self.humidity_critical[0] <= self.humidity <= self.humidity_critical[1]):
            self.led_colors.append("Rouge")
            self.led_stick.LedRGB_ON(2, 255, 0, 0)  # Rouge
        elif not (self.humidity_threshold[0] <= self.humidity <= self.humidity_threshold[1]):
            self.led_colors.append("Orange")
            self.led_stick.LedRGB_ON(2, 255, 165, 0)  # Orange
        else:
            self.led_colors.append("Vert")
            self.led_stick.LedRGB_ON(2, 0, 255, 0)  # Vert

        # LED 4 : Présence
        if self.presence_detected:
            self.led_colors.append("Bleu")
            self.led_stick.LedRGB_ON(3, 0, 0, 255)  # Bleu
        else:
            self.led_colors.append("Éteint")
            self.led_stick.LedRGB_ON(3, 0, 0, 0)  # Éteint

        # LED 5 : Qualité de l'air (CO2)
        if self.air_co2 > self.gas_critical:
            self.led_colors.append("Rouge")
            self.led_stick.LedRGB_ON(4, 255, 0, 0)  # Rouge
        elif self.air_co2 > self.gas_threshold:
            self.led_colors.append("Orange")
            self.led_stick.LedRGB_ON(4, 255, 165, 0)  # Orange
        else:
            self.led_colors.append("Vert")
            self.led_stick.LedRGB_ON(4, 0, 255, 0)  # Vert

        # LED 6 : Nanoparticules
        if self.nano_particles > self.nano_particles_critical:
            self.led_colors.append("Rouge")
            self.led_stick.LedRGB_ON(5, 255, 0, 0)  # Rouge
        elif self.nano_particles > self.nano_particles_threshold:
            self.led_colors.append("Orange")
            self.led_stick.LedRGB_ON(5, 255, 165, 0)  # Orange
        else:
            self.led_colors.append("Vert")
            self.led_stick.LedRGB_ON(5, 0, 255, 0)  # Vert

        print("LEDs mises à jour selon les composants")

    def outputProcessing(self):
        # Détermine si le buzzer doit être activé ou désactivé
        print("Traitement des sorties")

        if self.manual_buzzer_control:
            self.buzzer_status = 1  # Activation manuelle
        else:
            self.buzzer_status = 1 if self.critical_alert else 0  # Activation selon alertes critiques

    def outputUpdate(self):
        # Applique les changements aux actionneurs
        print("Mise à jour des sorties")

        if self.buzzer_status:
            self.buzzer.on()  # Active le buzzer
            print("Buzzer activé")
        else:
            self.buzzer.off()  # Désactive le buzzer
            print("Buzzer désactivé")
