import time
from lib.buttonLED import buttonLED
from lib.buzzer import buzzer
from lib.ledstick import ledStick
from lib.sensorAirquality import sensorAirquality
from lib.sensorDHT import sensorDHT
from lib.sensorPIR import sensorPIR
from lib.sensorSound import sensorSound


class gateway:
    def __init__(self):
        print("Initialisation de la passerelle")

        self.bLed1 = buttonLED.GroveButtonLed(6, 5)
        self.bLed2 = buttonLED.GroveButtonLed(17, 1)
        self.buzzer = buzzer.GroveBuzzer(22)
        self.led_stick = ledStick.GroveLedStick(12, 10)
        self.air_quality_sensor = sensorAirquality.GroveAirQualitySensor()
        self.dht_sensor = sensorDHT.GroveDHTSensor(26)
        self.pir_sensor = sensorPIR.GrovePirMotionSensor(18)
        self.sound_sensor = sensorSound.GroveSoundSensor(0)

        self.buzzer_status = 0
        self.manual_buzzer_control = False
        self.critical_alert = False
        self.presence_detected = False
        self.previous_presence_state = False

        self.sound_threshold = 500
        self.sound_critical = 600
        self.temperature_threshold = (18, 30)
        self.temperature_critical = (16, 33)
        self.humidity_threshold = (40, 70)
        self.humidity_critical = (30, 80)
        self.nano_particles_threshold = 120
        self.nano_particles_critical = 150
        self.gas_threshold = 800
        self.gas_critical = 1100

    def inputUpdate(self):
        print("Mise à jour des entrées")

        self.bLed1_status = self.bLed1.getStatusButton()
        self.bLed2_status = self.bLed2.getStatusButton()

        if self.bLed1_status == 0:
            print("Bouton 1 pressé : Réinitialisation des alertes")
            self.critical_alert = False
            self.bLed1.setStatusLed(1)
        else:
            self.bLed1.setStatusLed(0)

        if self.bLed2_status == 0:
            print("Bouton 2 pressé : Activation/Désactivation manuelle du buzzer")
            self.manual_buzzer_control = not self.manual_buzzer_control
            self.bLed2.setStatusLed(1 if self.manual_buzzer_control else 0)

        self.air_quality = self.air_quality_sensor.getRawSensorValue()
        self.nano_particles = self.air_quality_sensor.TVoC()
        self.air_co2 = self.air_quality_sensor.CO2eq()
        self.dht = self.dht_sensor.getRawSensorValue()
        self.temperature = self.dht_sensor.temperature()
        self.humidity = self.dht_sensor.humidity()
        self.previous_presence_state = self.presence_detected
        self.presence_detected = self.pir_sensor.getSensorValue()
        self.sound_level = self.sound_sensor.getRawSensorValue()

        print(f"Niveau sonore : {self.sound_level} (0-1023)")
        print(f"Température : {self.temperature}°C, Humidité : {self.humidity}%")
        print(f"Qualité de l'air (CO2) : {self.air_co2} ppb")
        print(f"Nanoparticules : {self.nano_particles} ppm")
        print(f"Présence détectée : {self.presence_detected}")

    def inputProcessing(self):
        print("Traitement des entrées")

        self.critical_alert = False

        if self.sound_level > self.sound_critical:
            print("Alerte critique : Niveau sonore au-dessus du seuil critique")
            self.critical_alert = True

        if not (self.temperature_critical[0] <= self.temperature <= self.temperature_critical[1]):
            print("Alerte critique : Température en dehors des limites critiques")
            self.critical_alert = True

        if not (self.humidity_critical[0] <= self.humidity <= self.humidity_critical[1]):
            print("Alerte critique : Humidité en dehors des limites critiques")
            self.critical_alert = True

        if self.air_co2 > self.gas_critical:
            print("Alerte critique : Qualité de l'air au-dessus du seuil critique (CO2)")
            self.critical_alert = True

        if self.nano_particles > self.nano_particles_critical:
            print("Alerte critique : Nanoparticules au-dessus du seuil critique")
            self.critical_alert = True

        if not self.presence_detected and self.previous_presence_state and self.critical_alert:
            print("Aucune présence détectée, réactivation automatique du buzzer")
            self.manual_buzzer_control = False

    def graph(self):
        print("Mise à jour des LEDs")

    def outputProcessing(self):
        print("Traitement des sorties")

    def outputUpdate(self):
        print("Mise à jour des sorties")
