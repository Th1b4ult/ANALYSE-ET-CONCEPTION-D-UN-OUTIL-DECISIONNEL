import paho.mqtt.client as mqtt

SERVEUR = 'localhost'
PORT = 1883
TOPIC = 'test_channel'
ACK_TOPIC = 'test_channel/ack'

client = mqtt.Client()

def on_connect(client, userdata, flags, rc):
    if rc == 0:
        print("Connecté au broker MQTT")
        client.subscribe(TOPIC)
    else:
        print(f"Échec de la connexion, code d'erreur : {rc}")

def on_message(client, userdata, msg):
    print(f"Message reçu sur {msg.topic} : {msg.payload.decode()}")
    
    ack_message = "ACK reçu pour " + msg.topic
    client.publish(ACK_TOPIC, ack_message, qos=1)
    print(f"Accusé de réception envoyé : {ack_message}")

client.on_connect = on_connect
client.on_message = on_message

client.connect(SERVEUR, PORT, 60)

client.loop_forever()
