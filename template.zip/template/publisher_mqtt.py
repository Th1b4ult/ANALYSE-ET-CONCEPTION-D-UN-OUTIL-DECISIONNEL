import paho.mqtt.client as mqtt
import time
import json
import gateway

# SERVEUR = 'localhost'
SERVEUR = '10.42.0.121'
PORT = 1883
TOPIC_BASE = 'capteurs/'

client = mqtt.Client()

def on_connect(client, userdata, flags, rc):
    if rc == 0:
        print("Connecté au broker MQTT")
    else:
        print(f"Echec de la connexion, code d'erreur : {rc}")

client.on_connect = on_connect
client.connect(SERVEUR, PORT, 60)
client.loop_start()

print("Initialisation du Raspberry Pi et des capteurs")
passerelleObject = gateway.gateway()
print("Passerelle prête, démarrage de la collecte des données")

try:
    while True:
        passerelleObject.inputUpdate()
        sensor_data = {
            "temperature": passerelleObject.temperature,
            "humidity": passerelleObject.humidity,
            "sound_level": passerelleObject.sound_level,
            "air_quality_co2": passerelleObject.air_co2,
            "nano_particles": passerelleObject.nano_particles,
            "presence_detected": passerelleObject.presence_detected
        }

        for key, value in sensor_data.items():
            topic = f"{TOPIC_BASE}{key}"
            message = json.dumps({"valeur": value})
            client.publish(topic, message, qos=1)
            print(f"Publié {key} -> {topic} : {message}")

        time.sleep(60)

except KeyboardInterrupt:
    print("\nArrêt du script")

finally:
    client.loop_stop()
    client.disconnect()
    print("Déconnecté du broker MQTT")
